// Manage segments (CRUD) 
