// Register for segments 
