

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="../Tailwind/output.css">
    </head>
    <body>
        <nav class="bg-gray-800 p-4">
                    <div class="container mx-auto flex justify-between items-center">
                         <a href="#" class="text-white text-lg font-semibold">EVENT.HOLD</a>
                         <div class="space-x-4">
                              <a href="#" class="text-gray-300 hover:text-white">Home</a>
                              <a href="#" class="text-gray-300 hover:text-white">Event</a>
                              <a href="#" class="text-gray-300 hover:text-white">Segment</a>
                              <a href="#" class="text-gray-300 hover:text-white-200">LogOut</a>
                         </div>
                    </div>
        </nav>





    </body>
</html>