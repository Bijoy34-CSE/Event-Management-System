<footer class="h-14 bg-gradient-to-r from-violet-500 to-fuchsia-500">
  <div class="footer-container">
    <div class="footer-about">
      <h3>About Us</h3>
      <p>Your company's mission statement or a brief description.</p>
    </div>
    <div class="footer-links">
      <h3>Quick Links</h3>
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="events.php">Events</a></li>
        <li><a href="segments.php">Segments</a></li>
        <li><a href="contact.php">Contact</a></li>
      </ul>
    </div>
    <div class="footer-contact">
      <h3>Contact</h3>
      <p>Address: Khulna University, Khulna, BD</p>
      <p>Phone: +880 123456-7890</p>
      <p>Email: sumon@soft-inc.com</p>
    </div>
  
  </div>
    <div class="footer-bottom">
        <p>&copy; 2024 Software Company. All rights reserved.</p>
    </div>
</footer>
